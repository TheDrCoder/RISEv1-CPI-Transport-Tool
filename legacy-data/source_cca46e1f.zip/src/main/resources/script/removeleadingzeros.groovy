import com.sap.it.api.mapping.*;
import groovy.time.TimeCategory

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String customFunc(String arg1){
	return arg1.replaceFirst("^0+","");
}


def String end_date(String arg1, String arg2){
    def acceptedFormat = "yyyy-MM-dd"
    def date = Date.parse(acceptedFormat, arg1)
    if(arg2.length()!=0){
        arg2 = arg2.replaceFirst("^0*", "");
        def validity = arg2.toInteger();
        use(TimeCategory) {
            String enddate = date + validity.month;
            return(Date.parse('E MMM dd HH:mm:ss z yyyy', enddate).format('yyyy-MM-dd'))
        //print(oneYear)
        }
    }
    
}