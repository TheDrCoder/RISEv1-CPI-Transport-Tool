import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    body = body.replaceAll('<ProductCategoryID xsi:nil="true" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">','<ProductCategoryID>60')
    message.setBody(body);
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("PostProcessingOutputPayload:", body, "text/plain");
     }
    return message;
}
