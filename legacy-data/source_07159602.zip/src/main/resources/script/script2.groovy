import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    //def messageLog = messageLogFactory.getMessageLog(message);
    if(body.contains("</Customer>")){
        message.setProperty("flag","true");
        message.setBody(body);
    }
    else{
       message.setProperty("flag","false");
       message.setBody(body);
    }
        
    return message;
}