<xsl:stylesheet version="2.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:xs="http://www.w3.org/2001/XMLSchema"
exclude-result-prefixes="xs">
<xsl:param name= "customerid"/>
<xsl:output omit-xml-declaration="yes" indent="yes"/>
<xsl:strip-space elements="*"/>

 <xsl:template match="node()|@*">
    <xsl:copy>
      <xsl:apply-templates select="node()|@*"/>
     </xsl:copy>
  </xsl:template>
 <xsl:template match="E1P0006[not( (xs:date(replace(ENDDA,'(\d{4})(\d{2})(\d{2})','$1-$2-$3'))) &gt; current-date())]"/>
</xsl:stylesheet>